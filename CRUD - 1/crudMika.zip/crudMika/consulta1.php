<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Consulta de Animais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px;
            display: flex;
            justify-content: space-between; /* Alinha o título e o ícone na horizontal */
            align-items: center; /* Alinha o título e o ícone na vertical */
        }

        h1 {
            margin: 0;
        }

        .container {
            max-width: fit-content;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ccc;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .btn {
            display: inline-block;
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 5px;
        }

        .btn-edit {
            background-color: #28a745;
        }

        .btn-delete {
            background-color: #dc3545;
        }

        .search-container {
            text-align: left;
            margin-bottom: 20px;
        }

        input[type="text"] {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .search-btn {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <header>
        <a href="index.php"><i class="fas fa-arrow-left"></i></a> <!-- Ícone de voltar -->
        <h1>Consulta de Animais</h1>
        <div></div> <!-- Espaço vazio para alinhar o ícone à direita -->
    </header>
    <div class="container">
        <div class="search-container">
            <form method="post">
                <input type="text" id="search" placeholder="Pesquisar código..." name="id">
                <input class="search-btn" type="submit" value="Consultar">

            </form>
        </div>
</body>

</html>
<?php
include("bd.php");
buscar();
?>